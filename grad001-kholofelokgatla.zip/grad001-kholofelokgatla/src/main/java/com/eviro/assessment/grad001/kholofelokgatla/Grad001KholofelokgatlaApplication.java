package com.eviro.assessment.grad001.kholofelokgatla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Grad001KholofelokgatlaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Grad001KholofelokgatlaApplication.class, args);
	}

}
