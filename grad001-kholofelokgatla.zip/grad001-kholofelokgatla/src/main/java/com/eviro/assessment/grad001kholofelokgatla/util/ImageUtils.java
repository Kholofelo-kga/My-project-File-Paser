package com.eviro.assessment.grad001kholofelokgatla.util;

import org.springframework.core.io.FileSystemResource;

import java.io.File;

public class ImageUtils {
    public static FileSystemResource getFileSystemResource(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            return new FileSystemResource(file);
        }
        return null;
    }
}
