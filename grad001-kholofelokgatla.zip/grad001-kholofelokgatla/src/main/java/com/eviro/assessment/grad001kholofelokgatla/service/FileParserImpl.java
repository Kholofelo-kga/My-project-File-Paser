package com.eviro.assessment.grad001kholofelokgatla.service;

import com.eviro.assessment.grad001kholofelokgatla.entities.AccountProfile;
import com.eviro.assessment.grad001kholofelokgatla.repository.AccountProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Base64;
import java.util.List;

@Component
public class FileParserImpl implements FileParser {
    private final AccountProfileRepository accountProfileRepository;

    @Autowired
    public FileParserImpl(AccountProfileRepository accountProfileRepository) {
        this.accountProfileRepository = accountProfileRepository;
    }

    @Override
    public void parseCSV(File csvFile) {
        try {
            // Read all lines from the CSV file
            List<String> lines = Files.readAllLines(csvFile.toPath());

            // Skip the header line if it exists
            if (!lines.isEmpty()) {
                lines = lines.subList(1, lines.size());
            }

            // Process each line and save records to the database
            for (String line : lines) {
                try {
                    String[] fields = line.split(",");

                    // Extract relevant data from the CSV line
                    String name = fields[0];
                    String surname = fields[1];
                    String base64ImageData = fields[2];

                    // Convert base64 image data to a physical image file
                    File imageFile = convertCSVDataToImage(base64ImageData);

                    // Create the HTTP image link for the file
                    String httpImageLink = createImageLink(imageFile);

                    // Create and save the AccountProfile entity
                    AccountProfile accountProfile = new AccountProfile();
                    accountProfile.setAccountHolderName(name);
                    accountProfile.setAccountHolderSurname(surname);
                    accountProfile.setHttpImageLink(httpImageLink);

                    accountProfileRepository.save(accountProfile);
                } catch (Exception e) {
                    // Handle the exception for a single line and continue processing the next line
                    System.out.println("Failed to process line: " + line);
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            System.out.println("Failed to read the CSV file: " + csvFile.getAbsolutePath());
            e.printStackTrace();
        }
    }

    @Override
    public File convertCSVDataToImage(String base64ImageData) {
        try {
            // Decode the base64 image data to a byte array
            byte[] imageData = Base64.getDecoder().decode(base64ImageData);

            // Create a new File object with a unique filename
            File imageFile = new File("image.jpg");

            // Write the byte array data to the file
            try (FileOutputStream fos = new FileOutputStream(imageFile)) {
                fos.write(imageData);
            }

            return imageFile;
        } catch (IOException e) {
            System.out.println("Failed to convert base64 image data to image file.");
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String createImageLink(File fileImage) {
        // Get the file's absolute path
        String filePath = fileImage.getAbsolutePath();

        // Construct the HTTP image link using the path
        String httpImageLink = "http://localhost:8080/v1/api/image/" + filePath.replace("\\", "/");

        return httpImageLink;
    }
}
