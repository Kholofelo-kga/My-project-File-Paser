package com.eviro.assessment.grad001kholofelokgatla.service;
import java.io.File;

public interface FileParser {
    void parseCSV(File csvFile);
    
    File convertCSVDataToImage(String base64ImageData);
    String createImageLink(File fileImage);
}
