package com.eviro.assessment.grad001kholofelokgatla.repository;



import com.eviro.assessment.grad001kholofelokgatla.entities.AccountProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountProfileRepository extends JpaRepository<AccountProfile, Long> {
}
