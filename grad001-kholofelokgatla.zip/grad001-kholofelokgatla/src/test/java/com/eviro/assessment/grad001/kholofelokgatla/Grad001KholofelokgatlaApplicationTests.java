package com.eviro.assessment.grad001.kholofelokgatla;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Grad001KholofelokgatlaApplicationTests {

	@Test
	void contextLoads() {
	}

}
